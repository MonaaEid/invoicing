<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Invoice_Item extends Model
{
    use HasFactory;

    public function buyer(){
        return $this->belongsTo(Buyer::class);
    }
    public function seller(){
        return $this->belongsTo(Seller::class);
    }
}
