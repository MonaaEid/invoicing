@extends('master')
@section('main-content')
<div class="col-md-10">
    <div class="card-body">
       
<div class="container">
    <div class="card-header">
        <h2>Products & Services</h2>
     </div>
     <div class="section-heading">
        @if(Session::has('status'))
            <p class="alert alert-info">{{ Session::get('status') }}</p>
        @endif
    </div>
    <table class="table table-striped">
       <tbody>
          <tr>
             <td>
                <form action="/store-product" method="post" autocomplete="off">
                    @csrf
                    <div class="row">
                        <div class="col-md-5">
                            <div id="Item-code" class="mb-3">
                                    <label for="Item-code" class="form-label">
                                        Item code
                                    </label>
                                     <input type="text" required name="product_code" maxlength="200" class="textinput textInput form-control" id="id_item_name_in_arabic">     
                            </div>
                        </div>
                         <div class="col-md-5">
                                <div id="name" class="mb-3">
                                        <label for="name" class="form-label">
                                            product name
                                        </label>     
                                         <input type="text" required name="name" maxlength="200" class="textinput textInput form-control" id="id_item_name_in_arabic">     
                                </div>
                        </div>
                    <div class="col-md-5">
                            <div id="name_in_arabic" class="mb-3">
                                    <label for="name_in_arabic" class="form-label">
                                        Item name in arabic
                                    </label>                                       
                                     <input type="text" required name="name_in_arabic" maxlength="200" class="textinput textInput form-control" id="id_item_name_in_arabic">     
                            </div>
                    </div>
                    <div class="col-md-5">
                        <div id="Price" class="mb-3">
                                <label for="Price" class="form-label">
                                    Price
                                </label>       
                                 <input type="text" required name="price" maxlength="200" class="textinput textInput form-control" id="id_item_name_in_arabic">     
                        </div>
                     </div>
                     
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-success btn-block btn-lg"><i class="fas fa-save"></i>
                                    save</button>
                            </div>
                            <div class="col-md-3">
                                <button type="" class="btn btn-danger btn-block btn-lg float-right"><i class="fas fa-backspace"></i>

                                    cancel</button>
                            </div>
                        </div>

                </form>
             </td>
            </tr>
        </tbody>
    </table>
</div>
@endsection
