@extends('master')
@section('main-content')

<div class="container" style="margin-top: 40px">
    <div class="card-header">
        <a href="/addProduct" class="btn btn-light" style="float:right">
            <i class="fas fa-plus"></i>Add New product
        </a>

        <h2>Invoice List</h2>
    </div>
    <br>

    <table class="table table-striped">
        <thead>
        <tr>
            <td>product Number</td>
            <td>product Name</td>
            <td>product code</td>
            <td>product name in Arabic</td>
            <td>price</td>

        </tr>
        </thead>

        <tbody>
  	 @foreach($products as $item)
        
        <tr>
            <td>{{$item->id}}</td>
            <td> {{$item->name}}</td>
            <td>{{$item->product_code}}</td>
            <td>{{$item->name_in_arabic}}</td>
            <td> {{$item->price}}</td>


            <td>
                {{-- <form method="GET" action="#">
                    @csrf --}}
                    <input name="_method" type="hidden" value="DELETE">
                    <button type="submit" class="btn btn-xs btn-danger btn-flat show_confirm" data-toggle="tooltip" title='Delete'>delete</button>
                {{-- </form>  --}}
            </td>
        </tr>
@endforeach
    </tbody>
</table>

</div>

<div class="blog">
    <div class="row">
      <div class="col-12">
          <ul class="pagination justify-content-center">
              @if($products->currentPage() > 1)
                <li class="page-item "><a class="page-link" href="{{$products->previousPageUrl()}}">Previous</a></li>
              @endif
                <li class="page-item">{{ $products->links() }}</li>
              @if($products->hasMorePages())
                <li class="page-item"><a class="page-link" href="{{$products->nextPageUrl()}}">Next</a></li>
              @endif
          </ul> 
      </div>
     </div>
    </div>
@endsection
