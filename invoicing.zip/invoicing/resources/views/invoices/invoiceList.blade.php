@extends('master')
@section('main-content')

<div class="container" style="margin-top: 40px">
    <div class="card-header">
        <a href="makeInvoice" class="btn btn-light" style="float:right">
            <i class="fas fa-plus"></i>Add New
        </a>

        <h2>Invoice List</h2>
    </div>
    <br>

    <table class="table table-striped">
        <thead>
        <tr>
            <td>Invoice Number</td>
            <td>Buyer Name</td>
            <td>Invoice Issue Date</td>
            <td>Invoice Total Amount</td>
            <td>Actions</td>

        </tr>
        </thead>

        <tbody>
  	 @foreach($invoices as $item)
        
        <tr>
            <td>{{$item->id}}</td>
            <td> {{$item->name}}</td>
            <td>{{$item->invoice_issue_date}}</td>
            <td> {{$item->total_amount_due}}</td>


            <td>
                <form method="GET" action="#">
                    @csrf
                    <input name="_method" type="hidden" value="DELETE">
                    <button type="submit" class="btn btn-xs btn-danger btn-flat show_confirm" data-toggle="tooltip" title='Delete'>delete</button>
                </form> 
                {{-- <a href="/invoice/view/1/" class="btn text-secondary px-0">
                    <i class="fas fa-eye fa-lg"></i>
                </a>
                <form action="/invoice/delete/1/" method="post" class="d-inline">
                    <input type="hidden" name="csrfmiddlewaretoken" value="6xrWQ96ETUo8WilUW8ZYT1m1qg5MMZPTnmWsahwCeXNG98ov8jVbVuETH6aHzLxQ">
                    <button type="submit" class="btn">
                        <i class="far fa-trash-alt fa-lg text-danger float-right"></i>
                    </button>
                </form> --}}
            </td>
        </tr>
@endforeach
    </tbody>
</table>

</div>

<div class="blog">
    <div class="row">
      <div class="col-12">
          <ul class="pagination justify-content-center">
              @if($invoices->currentPage() > 1)
                <li class="page-item "><a class="page-link" href="{{$invoices->previousPageUrl()}}">Previous</a></li>
              @endif
                <li class="page-item">{{ $invoices->links() }}</li>
              @if($invoices->hasMorePages())
                <li class="page-item"><a class="page-link" href="{{$invoices->nextPageUrl()}}">Next</a></li>
              @endif
          </ul> 
      </div>
     </div>
    </div>
@endsection