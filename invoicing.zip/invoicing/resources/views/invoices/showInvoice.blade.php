@extends('master')
@section('main-content')
<div class="section-heading">
    @if(Session::has('status'))
        <p class="alert alert-info">{{ Session::get('status') }}</p>
    @endif
</div>
<br>

<div id="" class="container ">
    <div class="section-header text-center">
      <h3>فاتورة </h3>
    </div>
    <form method="POST" action="/store-invoice">
        @csrf
    <section class=" d-flex p-2 bd-highlight" >

        <table class="table table-bordered border-primary">
            <thead>

            </thead>
            <tbody>
                <tr>
                    <td style="text-align:center">Date Of Supply</td>
                                             <td><input type="date" required format="%m/%d/%y" name="date_of_supply" id="datesupply" class="form-control">

                                         </td>
                    <td style="text-align:center">تاريخ التوريد</td>
                </tr>

                <tr>
                    <td style="text-align:center">Branch</td>
                      <td><input type="text" required name="branch" class="form-control">
                                  </td>

                    <td style="text-align:center"> الفرع</td>
                </tr>
                <tr>
                    <td style="text-align:center">Salesman Name</td>
                                       <td><input type="text" required name="salesman_name" class="form-control"
                                           ></td>
                    <td style="text-align:center"> اسم البائع</td>
                </tr>
            </tbody>
        </table>
        <table class="table table-bordered border-primary">
            <thead>

            </thead>
            <tbody>
                <tr>
                    <td style="text-align:center">Invoice Number</td>
                    <td><input type="number" name="invoice_number" value="{{$invoic_id}}" id="id_invoice_number"><input type="hidden" name="initial-invoice_number" value="33" id="initial-id_invoice_number"></td>


                    <td style="text-align:center"> رقم الفاتوره</td>
                </tr>
                <tr>
                    <td style="text-align:center"> Invoice issue Date</td>
                    <td><input required type="text" name="invoice_issue_date" value="2022-03-21 18:28:37" id="id_invoice_issue_date"><input type="hidden" name="initial-invoice_issue_date" value="2022-03-21 18:28:37" id="initial-id_invoice_issue_date"></td>
                    <td style="text-align:center"> تاريخ اصدار الفاتوره</td>
                </tr>
                <tr>
                    <td style="text-align:center"> Page No</td>
                    <td><input type="text" name="page_number" class="form-control" ></td>
                    <td required style="text-align:center"> رقم الصفحه</td>
                </tr>
            </tbody>
        </table>
      </section>

    <section class=" d-flex p-2 bd-highlight" >
        <table class="table table-bordered">
            <thead>
                <th>Seller</th>
                <th></th>
                <th style="text-align:right">المورد</th>
            </thead>
            <tbody>
                <tr>
                  
                    <td style="text-align:center">Name</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->organization_name}}" style="height:25px"
                            readonly>
                            <input type="text" class="form-control"  name="seller_id"
                            value="{{$seller->id}}" style="height:25px"
                            hidden>
                    </td>

                    <td style="text-align:center">الاسم</td>
                </tr>
                <tr>
                    <td style="text-align:center">Building No</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->building_no}}" style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">رقم المبني</td>
                </tr>
                <tr>
                    <td style="text-align:center">Street Name</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->street_name}}" style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">اسم الشارع</td>
                </tr>
                <tr>
                    <td style="text-align:center">District</td>
                    <td><input type="text" class="form-control" value="{{$seller->district}}"
                            style="height:25px" readonly>
                    </td>

                    <td style="text-align:center"> الحي</td>
                </tr>
                <tr>
                    <td style="text-align:center">City</td>
                    <td><input type="text" class="form-control" value="{{$seller->city}}"
                            style="height:25px" readonly>
                    </td>

                    <td style="text-align:center"> المدينة</td>
                </tr>

                <tr>
                    <td style="text-align:center">Country</td>
                    <td><input type="text" class="form-control" value="{{$seller->country}}"
                            style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">البلد</td>
                </tr>
                <tr>
                    <td style="text-align:center">Postal Code</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->postal_code}}" style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">الرمز البريدي</td>

                </tr>
                <tr>
                    <td style="text-align:center"> Additional No</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->additional_number}}" style="height:25px"
                            readonly>
                    </td>
                    <td style="text-align:center"> رقم اضافي للعنوان</td>

                </tr>

                <tr>
                    <td style="text-align:center">VAT Number</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->vat_number}}" style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">الرقم الضريبي</td>

                </tr>
                <tr>
                    <td style="text-align:center">Other Seller ID</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->other_seller_id}}" style="height:25px" readonly>
                    </td>
                    <td style="text-align:center"> معرف اخر</td>
                </tr>
            </tbody>
        </table>

    {{-- BUYER TABLE --}}
        <table class="table table-bordered">
            <thead>

                <th>Buyer</th>
                <th></th>
                <th style="text-align: right">العميل</th>

            </thead>
            <tbody>
                <tr>
                    <td style="text-align:center">Name</td>
                                        <td><input required type="text" name="name" class="form-control"
                                                    style="height:25px">
                                      </td>
                    <!--                             <td></td>-->
                    <td style="text-align:center">الاسم</td>
                </tr>
                <tr>
                    <td style="text-align:center">Building No</td>
                                         <td><input required type="number" name="building_no" class="form-control"
                 style="height:25px"></td>
                    <td style="text-align:center">رقم المبني</td>
                </tr>
                <tr>
                    <td style="text-align:center">Street Name</td>
                                           <td><input required type="text" name="street_name" class="form-control"
                                                       style="height:25px"></td>
                    <td style="text-align:center">اسم الشارع</td>
                </tr>
                <tr>
                    <td style="text-align:center">District</td>
                                             <td><input value="{{$item->buyer->postal_code}}" type="text"  name="district" class="form-control"
                                                    style="height:25px"></td>

                    <td style="text-align:center"> الحي</td>
                </tr>
                <tr>
                    <td style="text-align:center">City</td>
                                      <td><input value="{{$item->buyer->country}}" type="text" required name="city" class="form-control"
                                style="height:25px"></td>

                    <td style="text-align:center"> المدينة</td>
                </tr>
                <tr>
                    <td style="text-align:center">Country</td>
                  <td><input value="{{$item->buyer->postal_code}}" type="text"  required name="country" class="form-control"
                                                  style="height:25px"></td>
                    <td style="text-align:center">البلد</td>
                </tr>
                <tr>
                    <td style="text-align:center">Postal Code</td>
              <td><input  value="{{$item->buyer->postal_code}}" type="number" required name="postal_code" class="form-control"
                   style="height:25px"></td>
                    <td style="text-align:center">الرمز البريدي</td>
                </tr>
                <tr>
                    <td style="text-align:center"> Additional No</td>
                                  <td><input value="{{$item->buyer->other_buyer_id}}" required type="number" name="additional_number" class="form-control"
                                         style="height:25px"></td>
                    <td style="text-align:center"> رقم اضافي للعنوان</td>

                </tr>
                <tr>
                    <td style="text-align:center">VAT Number</td>
                                       <td><input value="{{$item->buyer->other_buyer_id}}" type="number" name="vat_number" class="form-control"
                                                 style="height:25px"></td>

                    <td style="text-align:center">الرقم الضريبي</td>

                </tr>
                <tr>
                    <td style="text-align:center">Other Buyer ID</td>
                                      <td><input value="{{$item->buyer->other_buyer_id}}" type="number" name="other_buyer_id" class="form-control"
                                                        style="height:25px"></td>
                    <td style="text-align:center"> معرف اخر</td>

                </tr>

            </tbody>

        </table>

    </section>

    <section class=" d-flex p-2 bd-highlight" >
        
    <div class="panel-heading">
        <h4 class="panel-title"><strong>Order Summary</strong></h4>
        <table class="table table-condensed">
            <thead>
                <tr>
                  
                    <td class="text-right"><strong>Description</strong></td>
                    
                    <td class="text-right"><strong>Price</strong></td>
                    <td class="text-right"><strong>Quantity</strong></td>
                    <td class="text-right"><strong>Taxable Amount</strong></td>
                    <td class="text-right"><strong>Tax percentage</strong></td>
                    <td class="text-right"><strong>Tax Amount</strong></td>
                    <td class="text-right"><strong>Sub Total</strong></td>

                </tr>
            </thead>
            <tbody id="summary-table-body">
                <tr id="total-tr">

             

                </tr>
            </tbody>
        </table>
    </div>
    </section>
    <section class=" d-flex p-2 bd-highlight" >
        <div class="col-md-12">
            <table class="table table-bordered" style="float:right; width:700px">
                    <tr>
                        <td>Total</td>
                        <td>
                            <input readonly name="total" id="total">
                        </td>
                    </tr>
        
                    <tr>
                        <td>Discount</td>

                        <td>
                            <input type="number" name="discount" id="discount" value="0">
                        </td>
                    </tr>
                    <tr>

                        <td>Total Taxable Amount</td>
                        <td>
                            <input readonly name="total_taxable_amount_exclude_vat" id="total_amount">
                        </td>
                    </tr>
                    <tr>
                        <td>Total VAT</td>

                        <td>
                            <input readonly name="total_vat" value="0" id="total_vat">
                        </td>
                    </tr>
                    <tr>
                        <td>Total Amount Due</td>

                        <td>
                            <input readonly name="total_amount_due" value="0" id="amount_due">
                        </td>
                    </tr>
            </table>
        </div>
    </section>
    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <button id="btnPrint" class="hidden-print">
            Print</button>
            &nbsp;
            <a href="/invoices-list" class="btn btn-primary btn-block float_right"><i
            class="fa-solid fa-list"></i>Back to list</a>
</div>
    </form>
</div>
<script>
let $btnPrint = document.querySelector("#btnPrint");

$btnPrint.addEventListener("click", () => {
window.print();
});

</script>
@endsection
