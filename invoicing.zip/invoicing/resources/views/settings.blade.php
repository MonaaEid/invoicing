@extends('master')
@section('main-content')
    

<div class="container">
    <div class="card-header">
        <h2>Seller</h2>
    </div>
    <div class="section-heading">
        @if(Session::has('status'))
            <p class="alert alert-info">{{ Session::get('status') }}</p>
        @endif
    </div>
    @if ($errors->any())
    <ul class="alert alert-danger">
        @foreach ($errors->all() as $error)
            <li>{{$error}}</li>
        @endforeach
    </ul>

@endif
    <table class="table table-striped">
        <tbody>
        <tr>
            <td>
                <form action="/store-seller" method="post" autocomplete="off" enctype="multipart/form-data">
                    @csrf
                    {{-- <input type="hidden" name="csrfmiddlewaretoken" value="hyB7iJjdyDmaEWzOSBJkQKhpFQMSnEdgyn6DCRJbTGLIRMCp4MFxSdzhWGRNaqVd"> --}}
                    <div class="row">
                        <div class="col-md-6">
                            <div id="1" class="mb-3">
                                <label for="1" class="form-label">
                                    organization name
                                </label>  
                                   <input required type="text" name="organization_name" class="numberinput form-control" id="">
                            </div>
                            <div id="div_id_building_number" class="mb-3">
                                <label for="id_building_number" class="form-label">
                                    Building number
                                </label>  
                                   <input required type="number" name="building_no" class="numberinput form-control" id="">
                            </div>
                            <div id="2" class="mb-3">
                                <label for="2" class="form-label">
                                    street name
                                </label>  
                                   <input required type="text" name="street_name" class="numberinput form-control" id="">
                            </div>
                            <div id="3" class="mb-3">
                                <label for="3" class="form-label">
                                    city 
                                </label>  
                                   <input required type="text" name="city" class="numberinput form-control" id="">
                            </div>

                            <div id="4" class="mb-3">
                                <label for="4" class="form-label">
                                   district
                                </label>  
                                   <input required type="text" name="district" class="numberinput form-control" id="">
                            </div>

                            <div id="5" class="mb-3">
                                <label for="5" class="form-label">
                                   country
                                </label>  
                                   <input required type="text" name="country" class="numberinput form-control" id="">
                            </div> 
                            
                            <div id="6" class="mb-3">
                                <label for="6" class="form-label">
                                   postal code
                                </label>  
                                   <input required type="text" name="postal_code" class="numberinput form-control" id="">
                            </div>

                            <div id="7" class="mb-3">
                                <label for="7" class="form-label">
                                   additional number
                                </label>  
                                   <input required type="text" name="additional_number" class="numberinput form-control" id="">
                            </div>

                            <div id="8" class="mb-3">
                                <label for="8" class="form-label">
                                   VAT number
                                </label>  
                                   <input required type="text" name="vat_number" class="numberinput form-control" id="">
                            </div>

                            <div id="9" class="mb-3">
                                <label for="9" class="form-label">
                                   other_seller_id
                                </label>  
                                   <input required type="text" name="other_seller_id" class="numberinput form-control" id="">
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-success btn-block btn-lg"><i class="fas fa-save"></i>
                                save
                            </button>
                        </div>
                    </div>


                </form>
            </td>
        </tr>
        </tbody>
    </table>
</div>



{{-- <script src=
                "https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js"
        integrity=
                "sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi"
        crossorigin="anonymous">

</script>
<script src=
                "https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js"
        integrity=
                "sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG"
        crossorigin="anonymous"></script> --}}
@endsection