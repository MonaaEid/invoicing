@extends('master')
@section('main-content')

<div class="section-heading">
    @if(Session::has('status'))
        <p class="alert alert-info">{{ Session::get('status') }}</p>
    @endif
</div>
<br>

<div id="" class="container " style="width:95%; height:50% ">
    <div class="section-header text-center">
      <h3> فاتورة بيع </h3>
    </div>
    <form method="POST" id="post-form" >
        @csrf
    <section class=" d-flex p-2 bd-highlight" >

        <table class="table table-bordered border-primary">
            <thead>

            </thead>
            <tbody>
                <tr>
                    <td style="text-align:center">Date Of Supply</td>
                                             <td><input type="date" required format="%m/%d/%y" name="date_of_supply" id="datesupply" class="form-control">

                                         </td>
                    <td style="text-align:center">تاريخ التوريد</td>
                </tr>

                <tr>
                    <td style="text-align:center">Branch</td>
                      <td><input type="text" required name="branch" class="form-control">
                                  </td>

                    <td style="text-align:center"> الفرع</td>
                </tr>
                <tr>
                    <td style="text-align:center">Salesman Name</td>
                                       <td><input type="text" required name="salesman_name" class="form-control"
                                           ></td>
                    <td style="text-align:center"> اسم البائع</td>
                </tr>
            </tbody>
        </table>
        <table class="table table-bordered border-primary">
            <thead>

            </thead>
            <tbody>
                <tr>
                    <td style="text-align:center">Invoice Number</td>
                    <td><input type="number" name="invoice_number" value="{{$invoic_id}}" id="id_invoice_number"><input type="hidden" name="initial-invoice_number" value="33" id="initial-id_invoice_number"></td>


                    <td style="text-align:center"> رقم الفاتوره</td>
                </tr>
                <tr>
                    <td style="text-align:center"> Invoice issue Date</td>
                    <td><input required type="text" name="invoice_issue_date" value="2022-03-21 18:28:37" id="id_invoice_issue_date"><input type="hidden" name="initial-invoice_issue_date" value="2022-03-21 18:28:37" id="initial-id_invoice_issue_date"></td>
                    <td style="text-align:center"> تاريخ اصدار الفاتوره</td>
                </tr>
                <tr>
                    <td style="text-align:center"> Page No</td>
                    <td><input type="text" name="page_number" class="form-control" ></td>
                    <td required style="text-align:center"> رقم الصفحه</td>
                </tr>
            </tbody>
        </table>
      </section>

    <section class=" d-flex p-2 bd-highlight" >
        <table class="table table-bordered">
            <thead>
                <th>Seller</th>
                <th></th>
                <th style="text-align:right">المورد</th>
            </thead>
            <tbody>
                <tr>
                  
                    <td style="text-align:center">Name</td>
                    <td><input type="text" name="seller_name" class="form-control"
                            value="{{$seller->organization_name}}" style="height:25px"
                            readonly>
                            <input type="text" class="form-control"  name="seller_id"
                            value="{{$seller->id}}" style="height:25px"
                            hidden>
                    </td>

                    <td style="text-align:center">الاسم</td>
                </tr>
                <tr>
                    <td style="text-align:center">Building No</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->building_no}}" style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">رقم المبني</td>
                </tr>
                <tr>
                    <td style="text-align:center">Street Name</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->street_name}}" style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">اسم الشارع</td>
                </tr>
                <tr>
                    <td style="text-align:center">District</td>
                    <td><input type="text" class="form-control" value="{{$seller->district}}"
                            style="height:25px" readonly>
                    </td>

                    <td style="text-align:center"> الحي</td>
                </tr>
                <tr>
                    <td style="text-align:center">City</td>
                    <td><input type="text" class="form-control" value="{{$seller->city}}"
                            style="height:25px" readonly>
                    </td>

                    <td style="text-align:center"> المدينة</td>
                </tr>

                <tr>
                    <td style="text-align:center">Country</td>
                    <td><input type="text" class="form-control" value="{{$seller->country}}"
                            style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">البلد</td>
                </tr>
                <tr>
                    <td style="text-align:center">Postal Code</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->postal_code}}" style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">الرمز البريدي</td>

                </tr>
                <tr>
                    <td style="text-align:center"> Additional No</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->additional_number}}" style="height:25px"
                            readonly>
                    </td>
                    <td style="text-align:center"> رقم اضافي للعنوان</td>

                </tr>

                <tr>
                    <td style="text-align:center">VAT Number</td>
                    <td><input type="text" name="vat_number" class="form-control"
                            value="{{$seller->vat_number}}" style="height:25px" readonly>
                    </td>

                    <td style="text-align:center">الرقم الضريبي</td>

                </tr>
                <tr>
                    <td style="text-align:center">Other Seller ID</td>
                    <td><input type="text" class="form-control"
                            value="{{$seller->other_seller_id}}" style="height:25px" readonly>
                    </td>
                    <td style="text-align:center"> معرف اخر</td>
                </tr>
            </tbody>
        </table>

    {{-- BUYER TABLE --}}
        <table class="table table-bordered">
            <thead>

                <th>Buyer</th>
                <th></th>
                <th style="text-align: right">العميل</th>

            </thead>
            <tbody>
                <tr>
                    <td style="text-align:center">Name</td>
                                        <td><input required type="text" name="name" class="form-control"
                                                    style="height:25px">
                                      </td>
                    <!--                             <td></td>-->
                    <td style="text-align:center">الاسم</td>
                </tr>
                <tr>
                    <td style="text-align:center">Building No</td>
                                         <td><input required type="number" name="building_no" class="form-control"
                 style="height:25px"></td>
                    <td style="text-align:center">رقم المبني</td>
                </tr>
                <tr>
                    <td style="text-align:center">Street Name</td>
                                           <td><input required type="text" name="street_name" class="form-control"
                                                       style="height:25px"></td>
                    <td style="text-align:center">اسم الشارع</td>
                </tr>
                <tr>
                    <td style="text-align:center">District</td>
                                             <td><input required type="text"  name="district" class="form-control"
                                                    style="height:25px"></td>

                    <td style="text-align:center"> الحي</td>
                </tr>
                <tr>
                    <td style="text-align:center">City</td>
                                      <td><input type="text" required name="city" class="form-control"
                                style="height:25px"></td>

                    <td style="text-align:center"> المدينة</td>
                </tr>
                <tr>
                    <td style="text-align:center">Country</td>
                  <td><input type="text"  required name="country" class="form-control"
                                                  style="height:25px"></td>
                    <td style="text-align:center">البلد</td>
                </tr>
                <tr>
                    <td style="text-align:center">Postal Code</td>
              <td><input type="number" required name="postal_code" class="form-control"
                   style="height:25px"></td>
                    <td style="text-align:center">الرمز البريدي</td>
                </tr>
                <tr>
                    <td style="text-align:center"> Additional No</td>
                                  <td><input required type="number" name="additional_number" class="form-control"
                                         style="height:25px"></td>
                    <td style="text-align:center"> رقم اضافي للعنوان</td>

                </tr>
                <tr>
                    <td style="text-align:center">VAT Number</td>
                                       <td><input required type="number" name="buyer_vat_number" class="form-control"
                                                 style="height:25px"></td>

                    <td style="text-align:center">الرقم الضريبي</td>

                </tr>
                <tr>
                    <td style="text-align:center">Other Buyer ID</td>
                                      <td><input required type="number" name="other_buyer_id" class="form-control"
                                                        style="height:25px"></td>
                    <td style="text-align:center"> معرف اخر</td>

                </tr>

            </tbody>

        </table>

    </section>
    <div class="card-body  " id="">
        @foreach ($products as $item)

        <a  onclick="myFunction(
            '{{$item->id}}' , '{{$item->name}}', '{{$item->product_code}}', '{{$item->price}}')"
            class="btn btn-outline-dark">
            {{$item->name}}
    </a>
    @endforeach
</div>
    <section class=" d-flex p-2 bd-highlight" >
        
    <div class="panel-heading">
        <h4 class="panel-title"><strong>Order Summary</strong></h4>
        <table class="table table-condensed">
            <thead>
                <tr>
                  
                    <td class="text-right"><strong>Description</strong></td>
                    
                    <td class="text-right"><strong>Price</strong></td>
                    <td class="text-right"><strong>Quantity</strong></td>
                    <td class="text-right"><strong>Taxable Amount</strong></td>
                    <td class="text-right"><strong>Tax percentage</strong></td>
                    <td class="text-right"><strong>Tax Amount</strong></td>
                    <td class="text-right"><strong>Sub Total</strong></td>

                </tr>
            </thead>
            <tbody id="summary-table-body">
                <tr id="total-tr">

             

                </tr>
            </tbody>
        </table>
    </div>
    </section>
    <section class=" d-flex p-2 bd-highlight" >

        <div  id="qrcode">
        {{-- {!! QrCode::size(300)->backgroundColor(255,90,0)->generate($seller->organization_name) !!} --}}

            {{-- <img src="data:image/png;base64, {!! base64_encode(QrCode::format('svg')->size(200)->errorCorrection('H')->generate('string')) !!}"> --}}
        </div>
        <div class="col-md-12">

            <table class="table table-bordered" style="float:right; width:700px">
                    <tr>
                        <td>Total</td>
                        <td>
                            <input readonly name="total" id="total">
                        </td>
                    </tr>
        
                    <tr>
                        <td>Discount</td>

                        <td>
                            <input type="number" name="discount" id="discount" value="0">
                        </td>
                    </tr>
                    <tr>

                        <td>Total Taxable Amount</td>
                        <td>
                            <input readonly name="total_taxable_amount_exclude_vat" id="total_amount">
                        </td>
                    </tr>
                    <tr>
                        <td>Total VAT</td>

                        <td>
                            <input readonly name="total_vat" value="0" id="total_vat">
                        </td>
                    </tr>
                    <tr>
                        <td>Total Amount Due</td>

                        <td>
                            <input readonly name="total_amount_due" value="0" id="amount_due">
                        </td>
                    </tr>
            </table>
        </div>

        {{-- <img src="data:image/png;base64, {!! base64_encode(QrCode::format('svg')->size(200)->errorCorrection('H')->generate('string')) !!}"> --}}
        {{-- THE BEST WAY
        <img src="data:image/png;base64, {!! $qrcode !!}"> --}}
       
    </section>
    <div class="SCREEN_VIEW_CONTAINER ">
        <button id="btnPrint" onclick="printscr()" class="hidden-print">
            Print</button>
            <button id="btnSubmit" type="submit" class="btn btn-primary btn-block">
            <i class="fa-solid fa-bookmark"></i>
            Close Bill
            </button>
            &nbsp;
            <a href="/invoice/list/" class="btn btn-primary btn-block float_right"><i
            class="fa-solid fa-list"></i>Back to list</a>
    </div>
    </form>
</div>
<script>
// let $btnPrint = document.querySelector("#btnPrint");

// $btnPrint.addEventListener("click", () => {
// window.print();
// });

    var i = 1;
    var t = 0;
    var v = 0;
    var total_amount_due =0;
    let taxable_amount=0;
    // let tax_amount=0;
    function myFunction(id, item_name, item_code, price) {
        var table = document.getElementById("summary-table-body");
        var row = table.insertRow(0);
      
        var td_name = row.insertCell(0);
       
        var td_price = row.insertCell(1);
        var td_quantity = row.insertCell(2);
        var td_taxable_amount = row.insertCell(3);
        var td_tax_rate = row.insertCell(4);
        var td_tax_amount = row.insertCell(5);
        var td_sub_total = row.insertCell(6);



        row.setAttribute("id", "foo");
        var price_id = "price".concat(i);
        var quantity_id = "quantity".concat(i);
        var taxable_amount_id = "taxable_amount".concat(i);

        var tax_rate_id = "tax_rate".concat(i);

        var tax_amount_id = "tax_amount".concat(i);
        var sub_total_id = "sub_total".concat(i);


        td_price.setAttribute("id", price_id);
        td_quantity.setAttribute("id", quantity_id);

        /*td_id.innerHTML = '' + id;*/
        td_name.innerHTML = '' + item_name;
       /* td_code.innerHTML = '' + item_code;*/
        td_price.innerHTML = '' + price;
        td_quantity.innerHTML = "<input type='number' name='quantity[]' id='quant" + i + "'><input type='number' value='"+id+"' hidden name=product_id[] id='pro" + i + "'>";
        td_taxable_amount.innerHTML = "<input type='number' class='taxable_amount' id='taxable_amount" + i + "'>";

        td_tax_rate.innerHTML = "<input type='number' name='tax[]' id='tax" + i + "'>";

        td_tax_amount.innerHTML = "<input readonly class='tax_amount' name='tax_amount[]' id='tax_amount" + i + "'>";
        td_sub_total.innerHTML = "<input readonly id='sub_total" + i + "'>";


        i++;

        var rowCount = $("#summary-table-body tr").length;
        $(document).ready(function () {
           
            for (let j = 1; j <= rowCount; j++) {
                // if( $("#sub_total" + j-1).val() == ''){
                //         alert("please complete the data" );

                //         };
                $("#quantity" + j).change(function () {
                   
                    var price = document.getElementById("price" + j).innerHTML;
                    var quantity = $("#quant" + j).val();
                    var taxable = price * quantity;
                    $("#taxable_amount" + j).val(taxable);
                    var rate = $("#tax" + j).val();

                    var tax_amount = (taxable * rate) / 100;
                        $("#tax_amount" + j).val(tax_amount);

                        var sub_total = (taxable + tax_amount);
                        $("#sub_total" + j).val(sub_total);
                      
                    taxableAmount();
                    taxAmount();

                    total();

                    $("#tax" + j).change(function () {
                        rate = $("#tax" + j).val();

                         tax_amount = (taxable * rate) / 100;
                        $("#tax_amount" + j).val(tax_amount);

                        var sub_total = (taxable + tax_amount);
                        $("#sub_total" + j).val(sub_total);
                        taxAmount();
                        total();

                    });
                });
               
            }
       


        });
        
      
    }
    
$('#btnSubmit').click(function(e){
 // OrderValidation();
 e.preventDefault(e);

$.ajax({

   url: "/store-invoice",

   method:'POST',

   data: $('#post-form').serialize(),

   success: function(qrcode) {
$('#qrcode').html(qrcode);
   

printscr();
// window.print();

   }
});

});

</script>
@endsection
