// $(document).ready(function(){
    $('.dynamic').change(function(value){
        //alert('monaaaa');
        if($(this).val() != '') {
            let value = $(this).val();
            console.log(value);

            $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                method:'GET' ,
                url:'/price' ,
                data:{value: value} ,
                dataType:'json' ,//return data will be json
                success: function (op) {
                    $("#price0").val(op);
                    // console.log(data.op);
                    console.log(op);
                    // alert('hello');
                }
            });
        }



    });


  let counter=1;
  $('#add').on("click",function(){
    $('#addHere').append("<div></div>");
    $('#addHere div:last').attr({
      class:"form-group form-inline mb-2",
      id:"div"+counter,
    });
    //append
    $('#addHere div:last').append(`
      <select class="aya form-control " ></select>
      <input value="1" type="number" min="1" class="form-control">
      <input type="text" class="form-control mo">
      <input type="button" class="rem  btn-danger" value=" x " onclick="rem()" >
    <br>
`);
    $('#addHere #div'+counter+' select').attr({'name':'product[]','id':'dynamic'+counter,'onchange':'fun(this)'});
    $('#addHere #div'+counter+' input:nth-child(2)').attr({'id':'quantity'+counter,'onchange':'fun2(this)' ,'name':'quantity[]'});
      $('#addHere #div'+counter+' input:nth-child(3)').attr('id','price'+counter);
    $('#addHere #div'+counter+' input:nth-child(4)').attr('id','rem'+counter);




        counter++;


  });
// });

$(document).on('click', '.rem', function(){
      $(this).closest('div').remove();
    });
    function total(){
      taxable_amount=$('#total_amount').val();
      tax_amount=$('#total_vat').val();
     total_amount_due=parseFloat(taxable_amount)+parseFloat(tax_amount);
     $("#amount_due").val(total_amount_due);
 }
 function taxableAmount(){
     var sum = 0;
     $(".taxable_amount").each(function(){
         var prodprice = Number($(this).val());
         sum = sum + prodprice;
         $("#total, #total_amount").val(sum);
                 });
 }
 function taxAmount(){
     var sum = 0;
     $(".tax_amount").each(function(){
         var prodprice = Number($(this).val());
         sum = sum + prodprice;
         $("#total_vat").val(sum);
             });
 }
//  function print(){
//   var prtContent = document.getElementById("printpart");
//   var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
//   WinPrint.document.write(prtContent.innerHTML);
//   WinPrint.document.close();
//   WinPrint.focus();
//   WinPrint.print();
//   WinPrint.close();
// }
function printscr(){
window.print();
  
  }