// $(function () {
//         $("#add").on("click", function() {
//
//             var val = $("#input").text();
//             if(val !== '') {
//                 var elem = $("<li></li>").attr(
//                     "name", "meal"
//                 )
//                     .text(val);

//                 $(elem).append("<button class='rem'></button>");
//                 $("#mylist").append(elem);
//                 $("#input").val("");
//                 $(".rem").on("click", function () {
//                     $(this).parent().remove();


//                 });
//             }
//         });


//     });
$(function () {
        // $("#add").on("click", function() {


        //    var optionVal = new Array();
        //     $('#input').each(function() {
        //     optionVal.push($(this).val());
        // });


        // });
        // function app(event){
        //     var optionVal= new Array();
        //     $('#input').each(function() {
        //         optionVal.push($(this).val());
        //     });
        // }
        // var mylist=[];
        // function myfunc() {
        //     var txt = $('#input').text();
        //     mylist.push();
        //     for (var i in mylist) {
        //         $("#list").append("<li></li>").text(txt);
        //     }
        //
        // }

   //  let optionVal =[];
   // $('#input').on("click",function() {

   //    $('#input').each(function () {
   //         optionVal.push($(this).val());
   //         console.log(optionVal);

   //           for (var i = 0; i < optionVal.length; i++) {

   //      }
   //      $("#list").append("<li></li>").attr({

   //              name:"meal"
   //              }
   //              ).text(optionVal);

   //     });
   // var val = $("#input").text();
   //  var optionVal =[];
   //  console.log(optionVal);
   //  // var output=optionVal;
   // $('#add').on("click",function() {

   //    $('#input').each(function () {
   //        optionVal.push($(this).val());
   //        console.log(optionVal);

   //        for (var i = 0; i < optionVal.length; i++) {

   //        }
   //        var elem = $("<div></div>").attr(
   //            "name", "meal"
   //        )
   //            .text(val);
   //    })
   //              $(elem).append("<button class='rem'></button>");
   //              $("#list").append(elem);
   //              $("#input").val("");
   //              $(".rem").on("click", function () {
   //                  $(this).parent().remove();


   //     });



   // })

   });
// <script>
//   $(document).ready(function(){
//     $('#add').on("click",function(){
//       $('#list').append(`
//         <div>
//           <input type="button" name="remove"  onclick="del(this)"/>
//         </div>
//       `);
//     });
//   });
//   function del(index){
     
//     console.log(index);
//   }
// </script>

