
<?php $__env->startSection('main-content'); ?>

<div class="container" style="margin-top: 40px">
    <div class="card-header">
        <a href="/addProduct" class="btn btn-light" style="float:right">
            <i class="fas fa-plus"></i>Add New product
        </a>

        <h2>Invoice List</h2>
    </div>
    <br>

    <table class="table table-striped">
        <thead>
        <tr>
            <td>product Number</td>
            <td>product Name</td>
            <td>product code</td>
            <td>product name in Arabic</td>
            <td>price</td>

        </tr>
        </thead>

        <tbody>
  	 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
            <td><?php echo e($item->id); ?></td>
            <td> <?php echo e($item->name); ?></td>
            <td><?php echo e($item->product_code); ?></td>
            <td><?php echo e($item->name_in_arabic); ?></td>
            <td> <?php echo e($item->price); ?></td>


            <td>
                
                    <input name="_method" type="hidden" value="DELETE">
                    <button type="submit" class="btn btn-xs btn-danger btn-flat show_confirm" data-toggle="tooltip" title='Delete'>delete</button>
                
            </td>
        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

</div>

<div class="blog">
    <div class="row">
      <div class="col-12">
          <ul class="pagination justify-content-center">
              <?php if($products->currentPage() > 1): ?>
                <li class="page-item "><a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>">Previous</a></li>
              <?php endif; ?>
                <li class="page-item"><?php echo e($products->links()); ?></li>
              <?php if($products->hasMorePages()): ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>">Next</a></li>
              <?php endif; ?>
          </ul> 
      </div>
     </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Develpoment\invoicing\resources\views/products/productsList.blade.php ENDPATH**/ ?>